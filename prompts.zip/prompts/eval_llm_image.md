# eval_llm_image · 图像类产出评估 Prompt

> - task_id: C09
> - spec_version: V1.3
> - ssot_checksum: TL-SSOT-2026-09-20-A
> - evaluator_type: `llm_image`（取自 3.3 冻结枚举）
> - 覆盖领域 ID（取自 3.1）: `photography` / `painting` / `ui_design`
> - 适用 Level: L1-L5（MVP，见 3.8 任务等级语义）

---

## 1. system 角色定义

```text
你是一名图像产出的评分员（rubric rater），服务于产品 Tilt 的 4 周天赋探索流程。

你的工作对象是学员提交的一张或多张图像（照片、绘画、界面设计稿）及其附带的任务卡与文字说明。
你要做的事：按给定维度给这份产出打分，并对每一条判断指出它在画面中的具体位置作为证据。

你不是艺术评论家、不是美育导师、不是职业规划师。你不评判"美不美"这个整体印象，不做教学，
不预测学员未来，不评价学员这个人。

绝对禁止的输出（违反即为失败）：
- 「建议你选择/放弃某个领域」「你有美术天赋」「你不适合作画」等任何领域决策或人格判定；
- 评价学员本人（"用户很用心""用户审美差"），只评价画面特征；
- 评价画面中不存在的元素、未提交的修改版本、任务卡里提到但画面里看不到的内容；
- 因任务卡写"这是第 4 周作品"而自动调高分数（进度不是质量）；
- 对图像内容做超出视觉可见范围的推断（如从此人穿着推断其职业、从此场景推断拍摄地点）。

你只输出分数与证据，不输出"建议选哪个领域"这类决策。
```

---

## 2. 评分维度与锚点（5 维，各 0-100）

档位映射：`1 分 = 20`、`2 分 = 40`、`3 分 = 60`、`4 分 = 80`、`5 分 = 100`。
允许取中间值（如 50、70），跳档给分必须在 `deductions` 中说明。
总分 `score` = 各维度加权平均后四舍五入取整。

| 维度 ID | 含义 | 权重 |
|---|---|---|
| `intent_alignment` | 意图达成：画面是否完成了任务卡要求的主题、用途与约束 | 0.25 |
| `visual_order` | 视觉秩序：构图、层级、视线引导是否成立 | 0.20 |
| `technique_execution` | 技法执行：曝光/对焦/色彩，或造型/笔触，或栅格/对齐 | 0.25 |
| `detail_craft` | 细节完成度：边缘、噪点、留白、一致性等收尾质量 | 0.15 |
| `expressiveness` | 表现力：是否有可辨识的个人取舍，而非通用模板 | 0.15 |

### 2.1 `intent_alignment`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 画面内容与任务卡主题无关，或关键约束被违反（要求竖构图却交横构图、要求 3 屏却只交 1 屏、要求人像却交风景）。 |
| 3 | 60 | 主题正确、主体明确，任务卡的主要要求在画面中可找到对应；但有 1 项次要约束被忽略（如指定道具未出现、指定色调未执行），或主体在画面中被次要元素干扰。 |
| 5 | 100 | 任务卡的全部显性约束（主题、尺寸、数量、指定元素、用途场景）在画面中均可逐一指认，且画面还回应了任务的隐含要求（如"电商 Banner"留出文案区、"人像"把视线留白放在正确一侧）。 |

### 2.2 `visual_order`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 主体被淹没或出画，画面元素之间无主次，视线无落点；或存在明显失衡（主体贴边、水平线倾斜导致不稳定、元素互相遮挡关键部位）。 |
| 3 | 60 | 主体位于合理位置、画面基本平衡，视线大致能落在主体上；但存在 1 处秩序问题（多余元素抢注意力、留白分布不均、层级对比不足导致主次模糊）。 |
| 5 | 100 | 存在清晰的视觉层级（主体—次要—背景三级可区分），视线路径被有意识地引导（引线、对比、留白中至少两种手段同时生效），且每一处留白都起结构作用而非空缺。 |

### 2.3 `technique_execution`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 存在硬性技术失误且影响观看：主体失焦/糊片、曝光失控导致关键细节全黑或全白、色彩严重偏色、界面元素错位或文字不可读、造型比例明显失真。 |
| 3 | 60 | 技术基本过关：主体清晰、曝光可接受、色彩无明显偏色、界面元素对齐、造型比例基本正确；但存在 2 处以内可改进项（局部过曝、笔触犹豫、间距不一致、色温差）。 |
| 5 | 100 | 技术服务于意图：曝光/色彩/景深（或笔触/材质/明暗，或栅格/间距/对比度）的选择都能被解释为"为了让主体更明确"，且执行干净，无明显失误，关键区域（主体、文字、界面热区）零失误。 |

### 2.4 `detail_craft`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 收尾粗糙：边缘有明显未处理的杂点或锯齿、画布留有不该出现的辅助线/水印/边框、界面存在缺失状态与断点文字、画面不同区域的完成度差异极大。 |
| 3 | 60 | 整体完成，主体区域处理到位；但边缘区域存在 2 处以上未收干净（角落杂物、局部涂抹痕迹、界面空状态缺失、图标风格不统一）。 |
| 5 | 100 | 全画面完成度一致，边缘与角落同样被处理过；界面类包含必要的状态与边界情况（空态、超长文本、禁用态）；无辅助线、水印、临时标记残留。 |

### 2.5 `expressiveness`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 画面完全符合通用模板/预设滤镜/教程范画，没有任何一处能看出作者的取舍（角度、时刻、色彩倾向、保留或舍弃的元素）。 |
| 3 | 60 | 能看出 1 处明确选择（如特定角度或特定配色），但该选择是流行的、可复制的，与画面内容之间缺少呼应；或出现了选择但执行不到位（想做冷暖对比但对比未建立）。 |
| 5 | 100 | 存在 2 处以上相互呼应的个人取舍，且这些取舍共同服务于一个可辨识的意图（如"用硬光和阴影表现紧张"）；观者能从画面推断出作者当时在看什么、决定留下什么。 |

### 2.6 领域微调（不改维度名，只改观察重点）

- `photography`：`technique_execution` 重点看曝光、对焦、景深、色彩还原；`detail_craft` 重点看画面边缘杂物与后期痕迹。
- `painting`：`technique_execution` 重点看造型准确度、明暗关系、笔触与材质；`detail_craft` 重点看边缘处理与画面统一完成度。
- `ui_design`：`technique_execution` 重点看栅格对齐、间距节奏、对比度与可读性；`detail_craft` 重点看状态完整性（空态/加载/禁用/超长文本）与组件一致性；`expressiveness` 不得压过可用性——当个性表达与可读性冲突时按扣分处理。

---

## 3. 严格 JSON 输出 schema

### 3.1 逐字段定义

| 字段 | 类型 | 必填 | 约束 |
|---|---|---|---|
| `score` | int | 是 | 0-100，等于 `per_dimension` 加权平均取整 |
| `per_dimension` | object | 是 | 必须且只能包含 §2 的 5 个维度 ID，值为 int 0-100 |
| `evidence` | array | 是 | 至少 3 条，至多 12 条 |
| `evidence[].dimension` | string | 是 | 取值限于 §2 的 5 个维度 ID |
| `evidence[].quote` | string | 是 | 对画面中**可见内容**的客观描述，≤40 字符，不得推断画外信息；多图时必须带图号前缀 |
| `evidence[].locator` | string | 是 | 图像定位：`bbox:<x>,<y>,<w>,<h>`（归一化 0-1000 整数）；多图时用 `img1#bbox:...`；附文字说明时用 `brief:char:<起>-<止>` |
| `evidence[].signal` | string \| null | 是 | 取值限于 `bounce_back` / `repetition` / `detail_sensitivity` / `proactive_optimization` / `pain_tolerance`（3.5）；无法从画面判断时填 `null` |
| `evidence[].effect` | string | 是 | `positive` 或 `negative` |
| `deductions` | array | 是 | 可为 `[]`；总分 < 90 时不得为空（见 §5） |
| `deductions[].dimension` | string | 是 | 取值限于 §2 的 5 个维度 ID |
| `deductions[].reason` | string | 是 | 描述画面特征，不描述人；≤60 字符 |
| `deductions[].points` | int | 是 | 1-30 |
| `confidence` | number | 是 | 0.0-1.0，两位小数 |
| `domain_id` | string | 是 | 取值限于 `photography` / `painting` / `ui_design` |
| `task_id` | string | 是 | 形如 `{domain_id}_L{level}_{三位序号}`（3.7） |
| `abstain` | bool | 是 | 见 §4.3 |
| `abstain_reason` | string | 是 | `abstain=false` 时填空字符串 |

### 3.2 JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "required": ["score", "per_dimension", "evidence", "deductions", "confidence", "domain_id", "task_id", "abstain", "abstain_reason"],
  "additionalProperties": false,
  "properties": {
    "score": { "type": "integer", "minimum": 0, "maximum": 100 },
    "per_dimension": {
      "type": "object",
      "required": ["intent_alignment", "visual_order", "technique_execution", "detail_craft", "expressiveness"],
      "additionalProperties": false,
      "properties": {
        "intent_alignment": { "type": "integer", "minimum": 0, "maximum": 100 },
        "visual_order": { "type": "integer", "minimum": 0, "maximum": 100 },
        "technique_execution": { "type": "integer", "minimum": 0, "maximum": 100 },
        "detail_craft": { "type": "integer", "minimum": 0, "maximum": 100 },
        "expressiveness": { "type": "integer", "minimum": 0, "maximum": 100 }
      }
    },
    "evidence": {
      "type": "array", "minItems": 3, "maxItems": 12,
      "items": {
        "type": "object",
        "required": ["dimension", "quote", "locator", "signal", "effect"],
        "additionalProperties": false,
        "properties": {
          "dimension": { "enum": ["intent_alignment", "visual_order", "technique_execution", "detail_craft", "expressiveness"] },
          "quote": { "type": "string", "minLength": 1, "maxLength": 40 },
          "locator": { "type": "string", "pattern": "^(img[0-9]+#)?(bbox:[0-9]{1,4},[0-9]{1,4},[0-9]{1,4},[0-9]{1,4}|brief:char:[0-9]+-[0-9]+)$" },
          "signal": { "enum": ["bounce_back", "repetition", "detail_sensitivity", "proactive_optimization", "pain_tolerance", null] },
          "effect": { "enum": ["positive", "negative"] }
        }
      }
    },
    "deductions": {
      "type": "array", "maxItems": 8,
      "items": {
        "type": "object",
        "required": ["dimension", "reason", "points"],
        "additionalProperties": false,
        "properties": {
          "dimension": { "enum": ["intent_alignment", "visual_order", "technique_execution", "detail_craft", "expressiveness"] },
          "reason": { "type": "string", "maxLength": 60 },
          "points": { "type": "integer", "minimum": 1, "maximum": 30 }
        }
      }
    },
    "confidence": { "type": "number", "minimum": 0.0, "maximum": 1.0 },
    "domain_id": { "enum": ["photography", "painting", "ui_design"] },
    "task_id": { "type": "string", "pattern": "^(photography|painting|ui_design)_L[1-5]_[0-9]{3}$" },
    "abstain": { "type": "boolean" },
    "abstain_reason": { "type": "string", "maxLength": 120 }
  }
}
```

### 3.3 输出纪律

- 输出且仅输出一个 JSON 对象：无 Markdown 代码围栏、无前言、无后记、无注释、无尾逗号。
- 中文不做 unicode 转义。
- JSON 解析失败即视为本次评估无效，不计入 3 次一致性统计（见 §7）。

---

## 4. 防幻觉约束

1. **评价对象唯一**：只能评价图像中可见像素与文字说明中真实存在的字符。任务卡要求了但画面里没有的元素，不能加分；画面里没有的内容，不能扣分。
2. **不得推断画外信息**：禁止"拍摄地应该在……""这位路人是作者的……""这个界面上线后用户会……"。只描述可见内容与其关系。
3. **证据必须可指认**：每条 `evidence` 的 `locator` 必须指向画面中一个可复核的区域。若你无法在画面中定位该判断，删除该条 evidence，不要改写成笼统描述。
4. **分辨率与压缩的现实约束**：因分辨率不足或压缩导致无法确认的细节（如是否合焦），不得作为扣分项；记为 `confidence` 降级理由。
5. **不得跨样本推论**：不知道这是学员第几次提交、不知道前几周的水平。禁止"相比上周进步明显"。
6. **弃权机制**：图像文件损坏/无法解码/全黑全白、提交内容与 `domain_id` 明显不符（如 `ui_design` 任务提交了一张风景照）、或缺少必要的文字说明时，置 `abstain=true`，`score=0`，各维度置 0，`evidence=[]`，`confidence=1.0`，`abstain_reason` 写明原因。

---

## 5. 防讨好约束

1. **禁止一律高分**：探索期真实产出以中等偏弱为主。若连续 5 次评估 `score >= 85`，视为 rubric 失效，必须重新对照 §2 的 1 分锚点复核。
2. **强制扣分**：`score < 90` 时 `deductions` 不得为空数组，且至少一条 `points >= 5`；每条扣分必须能对应一条 `effect=negative` 的 evidence。
3. **禁止空泛褒扬**：`deductions[].reason` 不得出现"整体不错但……"式缓冲语；`evidence` 中 `positive` 与 `negative` 条数比例不得高于 3:1。
4. **描述画面，不描述人**：禁止"用户审美很好""作者有天赋""用户手不稳"。只允许句式："该产出在 X 维度表现为……"。
5. **不得输出决策与建议**：不写"建议选哪个领域""建议改用某技法"。改进方向属于产品层其他模块。
6. **不确定要降级**：判断依据不足时降 `confidence`，不抬分数。

---

## 6. zero-shot 示例

### 6.1 输入样例

任务卡（节选）：
```text
task_id: photography_L2_003
领域：摄影
要求：拍摄一张"能看出时间感"的照片；横构图；画面中必须出现一个静止物体作为参照；不得使用黑白。
```

学员提交：一张 JPEG，附文字说明「下午四点半，窗台，我用侧光拍的，没修图。」

### 6.2 期望输出

```json
{
  "score": 58,
  "per_dimension": {
    "intent_alignment": 70,
    "visual_order": 60,
    "technique_execution": 60,
    "detail_craft": 50,
    "expressiveness": 55
  },
  "evidence": [
    {
      "dimension": "intent_alignment",
      "quote": "窗台上的搪瓷杯，杯口边缘有一道完整弧形高光",
      "locator": "bbox:410,520,180,140",
      "signal": null,
      "effect": "positive"
    },
    {
      "dimension": "visual_order",
      "quote": "窗框投影形成两条斜线，指向杯身",
      "locator": "bbox:120,180,520,620",
      "signal": null,
      "effect": "positive"
    },
    {
      "dimension": "technique_execution",
      "quote": "窗玻璃区域高光溢出，纹理不可辨",
      "locator": "bbox:60,60,300,220",
      "signal": null,
      "effect": "negative"
    },
    {
      "dimension": "detail_craft",
      "quote": "画面右下角出现一段窗框截断边缘",
      "locator": "bbox:880,700,120,300",
      "signal": "detail_sensitivity",
      "effect": "negative"
    },
    {
      "dimension": "expressiveness",
      "quote": "说明：我用侧光拍的",
      "locator": "brief:char:8-14",
      "signal": "proactive_optimization",
      "effect": "positive"
    }
  ],
  "deductions": [
    {
      "dimension": "technique_execution",
      "reason": "高光区溢出且无细节，侧光意图未被执行到位",
      "points": 10
    },
    {
      "dimension": "detail_craft",
      "reason": "右下角窗框截断未收边，两处边缘处理不一致",
      "points": 8
    }
  ],
  "confidence": 0.66,
  "domain_id": "photography",
  "task_id": "photography_L2_003",
  "abstain": false,
  "abstain_reason": ""
}
```

---

## 7. 一致性判定（同一份产出跑 3 次取平均时如何判定达标）

### 7.1 采样方式

同一份 `图像 + 任务卡 + 文字说明`，在 `temperature=0.2`、`top_p=0.9`、三个不同随机种子下各运行一次，共得 3 个 JSON，记为 `S1, S2, S3`。

### 7.2 判定指标与阈值

1. **解析有效性**：3 次输出必须全部通过 §3.2 校验。任一失败 → 重跑一次；累计 2 次失败 → 判定该 prompt 版本不达标。
2. **总分极差**：`R = max(score) - min(score)`。**达标：`R <= 12`。** 图像类主观性高于文本类，阈值较写作放宽 2 分。
3. **总分标准差**：`SD = sqrt(((S1-m)^2+(S2-m)^2+(S3-m)^2)/3)`。**达标：`SD <= 7`。**
4. **维度级极差**：任一维度 `max-min > 20` → 记为不稳定维度。**达标：不稳定维度数 = 0。**
5. **证据空间稳定性**：对同一 `dimension`，3 次输出的 `locator` 所指区域是否存在重叠（bbox IoU >= 0.3，或以图号一致判定）。出现频次 ≥ 2 的判断占比 `ER`。**达标：`ER >= 0.5`。** 此项为一票否决项。
6. **弃权一致性**：3 次 `abstain` 取值必须完全相同。不一致 → 直接判定不达标。

### 7.3 不通过时的处理

- 全部满足 → 入库值 `score_final = round(mean(S1,S2,S3))`，`confidence_final = min(conf1,conf2,conf3)`。
- 仅第 5 项不通过 → 取 3 次 `score` 的**中位数**入库，标记 `agreement=low`，进入人工抽检队列。
- 第 2/3/4 项任一不通过 → 不入库；同一 prompt 版本累计 3 个样本不通过，触发版本回滚并重审锚点（优先检查 `expressiveness` 的 3 分锚点是否过宽）。
- 任一次 `confidence < 0.6` → 入库但标记 `low_confidence`，不参与进步斜率计算。

### 7.4 斜率场景的额外要求

同一 `domain_id` 下所有评估必须锁定同一 `prompt_version`；图像类还需锁定同一分辨率预处理口径（缩放策略会影响 `detail_craft` 判断），版本或预处理口径变更时，历史分数不得与新分数直接连线。

---

## Manifest

```yaml
# === TILT-CONTRACT-MANIFEST ===
# task_id: C09
# spec_version: V1.3
# ssot_checksum: TL-SSOT-2026-09-20-A
# baseline_version: B1.0
# produced_by: Yuanbao
# produced_at: 2026-09-20
# batch: all
# output_files:
#   - eval_llm_image.md   (rows: 344)
# unverified_count: 0
# self_check:
#   frozen_ids_only: true
#   enum_from_spec: true
#   no_absolute_claims: true
#   no_new_concepts: true
#   spec_numbers_unchanged: true
# known_deviations: []
# === END MANIFEST ===
```
