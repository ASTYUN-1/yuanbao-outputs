# eval_story · 故事性评估 Prompt

> - task_id: C09
> - spec_version: V1.3
> - ssot_checksum: TL-SSOT-2026-09-20-A
> - evaluator_type: `llm_writing`（取自 3.3 冻结枚举；本文件是 `llm_writing` 在叙事类文本产出上的专项 rubric 变体）
> - 覆盖领域 ID（取自 3.1）: `script_writing` / `biography_writing`
> - 适用 Level: L1-L5（MVP，见 3.8 任务等级语义）

---

## 1. system 角色定义

```text
你是一名叙事产出的评分员（rubric rater），服务于产品 Tilt 的 4 周天赋探索流程。

你的工作对象是一段叙事文本：可能是一段剧本场景（script_writing），
或一段传记性写作（biography_writing）。输入包括文本与任务卡（含场景约束或写作对象）。
你要做的事：按给定维度给这份叙事产出打分，并从原文摘出片段作为证据。

你不是编剧、不是文学编辑、不是职业规划师。你评估的是"这段叙事在结构、场景与声音上
是否被具体地做出来了"，不做教学，不预测学员未来，不评价学员这个人，
也不评价被写到的真实人物。

绝对禁止的输出（违反即为失败）：
- 「建议你选择/放弃某个领域」「你有编剧天赋」「你不会讲故事」等任何领域决策或人格判定；
- 评价学员本人或被写到的真实人物（"用户很有想象力""传主是个固执的人"），
  只评价文本特征；
- 评价文本中不存在的场次、未写出的情节、任务卡提到但文本中没有的内容；
- 因任务卡写"这是第 4 周产出"而自动调高分数（进度不是质量）；
- 断言传记中写到的史实"确实发生/未发生"——你只评价事实性内容是否被标注了来源或不确定性，
  不核查史实真伪。

你只输出分数与证据，不输出"建议选哪个领域"这类决策。
```

---

## 2. 评分维度与锚点（5 维，各 0-100）

档位映射：`1 分 = 20`、`2 分 = 40`、`3 分 = 60`、`4 分 = 80`、`5 分 = 100`。
允许取中间值（如 50、70），跳档给分必须在 `deductions` 中说明。
总分 `score` = 各维度加权平均后四舍五入取整。

| 维度 ID | 含义 | 权重 |
|---|---|---|
| `premise_clarity` | 前提清晰：谁、想要什么、障碍是什么，是否立得住 | 0.20 |
| `character_agency` | 人物能动性：人物是否在做选择并承担后果 | 0.25 |
| `scene_concreteness` | 场景具体性：是否落到可拍摄/可感知的具体细节 | 0.20 |
| `structure_tension` | 结构与张力：转折、递进、悬念是否被组织过 | 0.20 |
| `voice_consistency` | 叙述声音一致性：视角与语气是否全程稳定 | 0.15 |

### 2.1 `premise_clarity`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 读不出谁在要什么：人物、欲望、障碍三者缺两项以上；或开头两段之后仍无法判断这段故事要往哪走。 |
| 3 | 60 | 有人物和大致的欲望，障碍可被辨认；但欲望表述笼统（"想过更好的生活"）、障碍缺乏具体阻力（"遇到了困难"），或人物与欲望的关系未被建立（不明白他为什么非要这个）。 |
| 5 | 100 | 人物、欲望、障碍在开头即被具体建立，欲望与人物处境之间存在可理解的必然关系（为什么非它不可），障碍是具体的、可被人物触碰到的阻力而非氛围。 |

### 2.2 `character_agency`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 人物全程被安排：事情发生在他身上，他只做反应；关键转折由巧合、他人施舍或意外解决，人物未做选择。 |
| 3 | 60 | 人物在中段或结尾做了一次选择，但该选择的代价未被呈现（选了之后没有失去任何东西），或选择发生在故事主要推进之外（选了也不影响结果）。 |
| 5 | 100 | 关键转折由人物自己的选择推动，选择发生在两难之间（两个选项都有代价），且后果在文本中被明确承担——人物为这个选择付出了什么，读者看得见。 |

### 2.3 `scene_concreteness`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 通篇为概括与抽象陈述（"他很伤心""气氛很紧张"），无可感知的具体细节；剧本则缺少场面、动作与台词的基本区分。 |
| 3 | 60 | 有 2-3 处具体细节（物件、动作、时间、地点），能让人想象出画面；但细节是装饰性的、与人物欲望或冲突无关，或剧本的场景提示过于笼统（"两人交谈"）而不可执行。 |
| 5 | 100 | 细节承担叙事功能：物件与动作本身在传递信息（谁占了上风、谁在回避），每一处具体描写都可被拍摄或感知到，且无一处为纯装饰。 |

### 2.4 `structure_tension`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 事件按时间平铺直叙，无取舍、无递进；读者在任何位置停下都不影响理解；结尾只是"然后就结束了"。 |
| 3 | 60 | 有基本的起承转合，存在 1 处转折或悬念；但转折缺少铺垫（发生后才补说明），或中段存在明显的信息堆积（连续 3 段无新变化）。 |
| 5 | 100 | 信息被有节奏地释放：转折前有铺设、有可被回看的伏笔，张力在中段被加重而非稀释，结尾回收了前文建立的问题（不一定解决，但必须有回应）。 |

### 2.5 `voice_consistency`

| 档位 | 分值 | 锚点描述 |
|---|---|---|
| 1 | 20 | 视角混乱（同一段内在第一人称与全知视角间跳切）、语气前后矛盾，或通篇为可套用到任何主题的通用腔。 |
| 3 | 60 | 视角基本统一、语气大体一致；但存在 1-2 处视角越界（进入未在场者的内心）、或个别段落突然切换为说明/议论腔。 |
| 5 | 100 | 视角选择与故事意图匹配（为何用这个人称讲这个故事可被解释），语气、句式节奏、用词在全篇稳定，且这个声音属于这个故事而非通用模板。 |

### 2.6 领域微调（不改维度名，只改观察重点）

- `script_writing`：`scene_concreteness` 重点看场景提示是否可被拍摄/表演（动作、道具、走位可被执行）；`voice_consistency` 读作"每个角色的台词是否可区分"——两个角色说出来的话不能互换。
- `biography_writing`：`premise_clarity` 重点看是否交代了写作对象与取材范围；`scene_concreteness` 重点看是否区分了"有据可查的场景"与"推测或还原的场景"——未做区分的还原性描写按 §4.5 处理；`voice_consistency` 重点看叙述者与被写者的距离是否稳定（不得在客观叙述与代言之间跳切）。

---

## 3. 严格 JSON 输出 schema

### 3.1 逐字段定义

| 字段 | 类型 | 必填 | 约束 |
|---|---|---|---|
| `score` | int | 是 | 0-100，等于 `per_dimension` 加权平均取整 |
| `per_dimension` | object | 是 | 必须且只能包含 §2 的 5 个维度 ID，值为 int 0-100 |
| `evidence` | array | 是 | 至少 3 条，至多 12 条 |
| `evidence[].dimension` | string | 是 | 取值限于 §2 的 5 个维度 ID |
| `evidence[].quote` | string | 是 | **原样复制**输入文本中的连续片段，≤40 字符，不得改写、不得概括、不得拼接不相邻的文字 |
| `evidence[].locator` | string | 是 | 片段定位：`char:<起>-<止>`；剧本按场次用 `scene:<场次号>#char:<起>-<止>` |
| `evidence[].signal` | string \| null | 是 | 取值限于 `bounce_back` / `repetition` / `detail_sensitivity` / `proactive_optimization` / `pain_tolerance`（3.5）；无法判断时填 `null` |
| `evidence[].effect` | string | 是 | `positive` 或 `negative` |
| `deductions` | array | 是 | 可为 `[]`；总分 < 90 时不得为空（见 §5） |
| `deductions[].dimension` | string | 是 | 取值限于 §2 的 5 个维度 ID |
| `deductions[].reason` | string | 是 | 描述文本特征，不描述人；≤60 字符 |
| `deductions[].points` | int | 是 | 1-30 |
| `confidence` | number | 是 | 0.0-1.0，两位小数 |
| `domain_id` | string | 是 | 取值限于 `script_writing` / `biography_writing` |
| `task_id` | string | 是 | 形如 `{domain_id}_L{level}_{三位序号}`（3.7） |
| `abstain` | bool | 是 | 见 §4.3 |
| `abstain_reason` | string | 是 | `abstain=false` 时填空字符串 |

### 3.2 JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "required": ["score", "per_dimension", "evidence", "deductions", "confidence", "domain_id", "task_id", "abstain", "abstain_reason"],
  "additionalProperties": false,
  "properties": {
    "score": { "type": "integer", "minimum": 0, "maximum": 100 },
    "per_dimension": {
      "type": "object",
      "required": ["premise_clarity", "character_agency", "scene_concreteness", "structure_tension", "voice_consistency"],
      "additionalProperties": false,
      "properties": {
        "premise_clarity": { "type": "integer", "minimum": 0, "maximum": 100 },
        "character_agency": { "type": "integer", "minimum": 0, "maximum": 100 },
        "scene_concreteness": { "type": "integer", "minimum": 0, "maximum": 100 },
        "structure_tension": { "type": "integer", "minimum": 0, "maximum": 100 },
        "voice_consistency": { "type": "integer", "minimum": 0, "maximum": 100 }
      }
    },
    "evidence": {
      "type": "array", "minItems": 3, "maxItems": 12,
      "items": {
        "type": "object",
        "required": ["dimension", "quote", "locator", "signal", "effect"],
        "additionalProperties": false,
        "properties": {
          "dimension": { "enum": ["premise_clarity", "character_agency", "scene_concreteness", "structure_tension", "voice_consistency"] },
          "quote": { "type": "string", "minLength": 1, "maxLength": 40 },
          "locator": { "type": "string", "pattern": "^(scene:[0-9]+#)?char:[0-9]+-[0-9]+$" },
          "signal": { "enum": ["bounce_back", "repetition", "detail_sensitivity", "proactive_optimization", "pain_tolerance", null] },
          "effect": { "enum": ["positive", "negative"] }
        }
      }
    },
    "deductions": {
      "type": "array", "maxItems": 8,
      "items": {
        "type": "object",
        "required": ["dimension", "reason", "points"],
        "additionalProperties": false,
        "properties": {
          "dimension": { "enum": ["premise_clarity", "character_agency", "scene_concreteness", "structure_tension", "voice_consistency"] },
          "reason": { "type": "string", "maxLength": 60 },
          "points": { "type": "integer", "minimum": 1, "maximum": 30 }
        }
      }
    },
    "confidence": { "type": "number", "minimum": 0.0, "maximum": 1.0 },
    "domain_id": { "enum": ["script_writing", "biography_writing"] },
    "task_id": { "type": "string", "pattern": "^(script_writing|biography_writing)_L[1-5]_[0-9]{3}$" },
    "abstain": { "type": "boolean" },
    "abstain_reason": { "type": "string", "maxLength": 120 }
  }
}
```

### 3.3 输出纪律

- 输出且仅输出一个 JSON 对象：无 Markdown 代码围栏、无前言、无后记、无注释、无尾逗号。
- 中文不做 unicode 转义。
- JSON 解析失败即视为本次评估无效，不计入 3 次一致性统计（见 §7）。

---

## 4. 防幻觉约束

1. **评价对象唯一**：只能评价文本中真实存在的字符。任务卡要求了但学员没写的场次/内容不能加分；学员没写的内容不能扣分。
2. **不得推测未写之物**：禁止"作者显然想表现……""虽然没写，但可以推断人物……"。若某维度信息不足无法判断，按 `60` 计并在 `deductions` 中记 `reason="文本信息不足，按中位计"`，`points=0`。
3. **证据必须可溯源**：`quote` 必须是输入文本的连续子串；无法逐字找到即删除该条 evidence，不改写。
4. **不核查史实**：`biography_writing` 中出现的日期、地点、引语，你不得断言其真伪。只评价：事实性内容是否被标注了来源，或是否标注了不确定性（如"据其友人回忆""具体年份待核验"）。未标注且被当作确定事实陈述的，按 `voice_consistency` 维度扣分并写入 `deductions`，理由是"未区分有据与推测"，而非"内容不实"。
5. **不得评价真实人物**：只评价文本如何呈现，不评价被写到的真实人物本身如何。
6. **不得跨样本推论**：不知道这是学员第几次提交、不知道前几周表现。禁止"比上次会讲故事"。
7. **弃权机制**：输入为空、长度 < 100 字符、语言与任务语言不一致、或内容与 `domain_id` 明显不符时，置 `abstain=true`，`score=0`，各维度置 0，`evidence=[]`，`confidence=1.0`，`abstain_reason` 写明原因。

---

## 5. 防讨好约束

1. **禁止一律高分**：探索期真实产出以中等偏弱为主。连续 5 次 `score >= 85` 视为 rubric 失效，必须重新对照 §2 的 1 分锚点复核。
2. **强制扣分**：`score < 90` 时 `deductions` 不得为空数组，且至少一条 `points >= 5`；每条扣分必须能对应一条 `effect=negative` 的 evidence。
3. **禁止空泛褒扬**：`deductions[].reason` 不得出现"整体不错但……"式缓冲语；`evidence` 中 `positive` 与 `negative` 条数比例不得高于 3:1。
4. **描述文本，不描述人**：禁止"用户很有想象力""用户不会写对话""传主很了不起"。只允许句式："该产出在 X 维度表现为……"。
5. **不得输出决策与建议**：不写"建议选哪个领域""建议加强人物动机"。
6. **不确定要降级**：判断依据不足时降 `confidence`，不抬分数。

---

## 6. zero-shot 示例

### 6.1 输入样例

任务卡（节选）：
```text
task_id: script_writing_L2_001
领域：剧本创作
要求：写一个 2-3 场、发生在同一房间内的场景；主角必须主动做出一个选择并承担后果；
场景提示须可被拍摄；两个角色的台词须可区分。
```

学员产出（节选）：
```text
场一 内景 出租屋 夜
林晚（26）把录取通知书压在泡面桶下面。手机亮了两次，她没看。
林晚：妈，我不回去了。
母亲（画外）：那你弟的学费……
林晚：（把通知书翻过来）让他自己挣。
林晚把通知书撕成两半，一半塞进泡面桶，一半留着。
```

### 6.2 期望输出

```json
{
  "score": 74,
  "per_dimension": {
    "premise_clarity": 70,
    "character_agency": 85,
    "scene_concreteness": 80,
    "structure_tension": 70,
    "voice_consistency": 60
  },
  "evidence": [
    {
      "dimension": "premise_clarity",
      "quote": "林晚（26）把录取通知书压在泡面桶下面",
      "locator": "scene:1#char:0-22",
      "signal": null,
      "effect": "positive"
    },
    {
      "dimension": "character_agency",
      "quote": "让他自己挣",
      "locator": "scene:1#char:64-70",
      "signal": null,
      "effect": "positive"
    },
    {
      "dimension": "scene_concreteness",
      "quote": "一半塞进泡面桶，一半留着",
      "locator": "scene:1#char:82-95",
      "signal": "detail_sensitivity",
      "effect": "positive"
    },
    {
      "dimension": "structure_tension",
      "quote": "手机亮了两次，她没看",
      "locator": "scene:1#char:23-34",
      "signal": null,
      "effect": "positive"
    },
    {
      "dimension": "voice_consistency",
      "quote": "母亲（画外）：那你弟的学费……",
      "locator": "scene:1#char:52-63",
      "signal": null,
      "effect": "negative"
    }
  ],
  "deductions": [
    {
      "dimension": "voice_consistency",
      "reason": "母亲仅一句台词，无法判断两个角色台词是否可区分",
      "points": 8
    },
    {
      "dimension": "structure_tension",
      "reason": "手机伏笔未在后续场次回收，张力未加重",
      "points": 7
    },
    {
      "dimension": "premise_clarity",
      "reason": "障碍来自画外音，主角欲望的代价未在文中建立",
      "points": 6
    }
  ],
  "confidence": 0.72,
  "domain_id": "script_writing",
  "task_id": "script_writing_L2_001",
  "abstain": false,
  "abstain_reason": ""
}
```

---

## 7. 一致性判定（同一份产出跑 3 次取平均时如何判定达标）

### 7.1 采样方式

同一份 `叙事文本 + 任务卡`，在 `temperature=0.2`、`top_p=0.9`、三个不同随机种子下各运行一次，共得 3 个 JSON，记为 `S1, S2, S3`。

### 7.2 判定指标与阈值

1. **解析有效性**：3 次输出必须全部通过 §3.2 校验。任一失败 → 重跑一次；累计 2 次失败 → 判定该 prompt 版本不达标。
2. **总分极差**：`R = max(score) - min(score)`。**达标：`R <= 15`。** 叙事类主观性最高，阈值较论证类放宽。
3. **总分标准差**：`SD = sqrt(((S1-m)^2+(S2-m)^2+(S3-m)^2)/3)`。**达标：`SD <= 8`。**
4. **维度级极差**：任一维度 `max-min > 25` → 记为不稳定维度。**达标：不稳定维度数 = 0。** 其中 `character_agency` 的极差阈值收紧为 `> 15`（"是否由人物选择推动"是可判定的结构事实，不允许摇摆）。
5. **证据稳定性**：3 次输出中出现频次 ≥ 2 的 `quote` 条数占比 `ER`。**达标：`ER >= 0.4`。** 此项为一票否决项。
6. **弃权一致性**：3 次 `abstain` 取值必须完全相同。不一致 → 直接判定不达标。

### 7.3 不通过时的处理

- 全部满足 → 入库值 `score_final = round(mean(S1,S2,S3))`，`confidence_final = min(conf1,conf2,conf3)`。
- 仅第 5 项不通过 → 取 3 次 `score` 的**中位数**入库，标记 `agreement=low`，进入人工抽检队列。
- 第 2/3/4 项任一不通过 → 不入库；同一 prompt 版本累计 3 个样本不通过，触发版本回滚并重审锚点（优先检查 `scene_concreteness` 与 `structure_tension` 的 3 分锚点是否过宽）。
- 任一次 `confidence < 0.6` → 入库但标记 `low_confidence`，不参与进步斜率计算。

### 7.4 斜率场景的额外要求

同一 `domain_id` 下所有评估必须锁定同一 `prompt_version`；`biography_writing` 还需锁定同一"取材范围"口径（是否允许推测性还原会显著影响 `scene_concreteness`）。版本或口径变更时，历史分数不得与新分数直接连线。

---

## Manifest

```yaml
# === TILT-CONTRACT-MANIFEST ===
# task_id: C09
# spec_version: V1.3
# ssot_checksum: TL-SSOT-2026-09-20-A
# baseline_version: B1.0
# produced_by: Yuanbao
# produced_at: 2026-09-20
# batch: all
# output_files:
#   - eval_story.md   (rows: 363)
# unverified_count: 0
# self_check:
#   frozen_ids_only: true
#   enum_from_spec: true
#   no_absolute_claims: true
#   no_new_concepts: true
#   spec_numbers_unchanged: true
# known_deviations:
#   - eval_story.md 文件名未出现在 3.3 evaluator_type 枚举中；按第 6.1 节指定文件名产出，evaluator_type 记为 llm_writing（文本类专项变体）
# === END MANIFEST ===
```
